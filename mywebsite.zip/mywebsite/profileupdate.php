<?php
session_start(); 

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webappproject";

$conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["csrf_token"] !== $_SESSION["csrf_token"]) {
        header("Location: error.php");
        exit;
    }

    $firstName = htmlspecialchars($_POST["firstName"], ENT_QUOTES, 'UTF-8');
    $lastName = htmlspecialchars($_POST["lastName"], ENT_QUOTES, 'UTF-8');
    $email = htmlspecialchars($_POST["email"], ENT_QUOTES, 'UTF-8');
    $postcode = htmlspecialchars($_POST["postcode"], ENT_QUOTES, 'UTF-8');

    $sql = "UPDATE users SET firstName = ?, lastName = ?, email = ?, postcode = ? WHERE userName = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $firstName, $lastName, $email, $postcode, $_SESSION['username']);
    $stmt->execute();

    header("Location: profile.php");
    exit;
}

$conn->close();
?>
