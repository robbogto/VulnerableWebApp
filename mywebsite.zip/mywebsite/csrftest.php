<form id="myForm" method="POST" action="profileupdate.php">
       
        <input type="hidden" id="firstName" name="firstName" value="CSRF" required><br>
       
        <input type="hidden" id="lastName" name="lastName" value="fail" required><br>
       
        <input type="hidden" id="email" name="email" value="csrf@mail.com" required><br>
        
        <input type="hidden" id="postcode" name="postcode" value="XXXXXX" required><br><br>
        <input type="hidden" name="csrf_token" value="notcorrecttoken">
        <input type="submit" value="Click here to view pictures">
    </form>
