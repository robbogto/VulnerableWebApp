<?php
    include_once 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
</head>
<body>
    <form method="POST" class="loginForm" action="register.php">
        <br><h2 style="text-align: center;">Sign Up</h2><br>
        <input type="text" class="textInput" name="username" placeholder="Enter a username" maxlength="30" required>
        <input type="password" class="textInput" id="password" name="password" placeholder="Enter a password" maxlength="30" required><br>
        <input class="logInButton" type="submit" value="Sign Up">
    </form>
</body>
</html>
