<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div id="S21card" class="card">
                <img id="s21CardImg" class="card-img-top" src="images/s21.jpg" alt="Samsung S21 Ultra">
            <div class="card-body">
                <h5 class="card-title">Samsung S21 Ultra 5G</h5>
                <p class="card-text">120 Hz 6.8 Inch Dynamic AMOLED display with the Exynos 2100 5nm processor</p>
                <p class="card-text">£699</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div><br>
    </section>



<?php
    include_once 'footer.php';
?>