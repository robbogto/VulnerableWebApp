<?php
$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webappproject";

$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$name = mysqli_real_escape_string($conn, $_POST['name']);
$productName = mysqli_real_escape_string($conn, $_POST['productName']);
$rating = mysqli_real_escape_string($conn, $_POST['rating']);
$comment = mysqli_real_escape_string($conn, $_POST['comment']);

$sql = "INSERT INTO reviews (name, productName, rating, comment) 
VALUES ('$name', '$productName', '$rating', '$comment')";

if (mysqli_query($conn, $sql)) {
    header("Location: reviews.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
