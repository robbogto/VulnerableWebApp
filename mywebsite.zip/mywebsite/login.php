<?php
    include_once 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>PHP Login Form</title>
</head>
<body>
<?php
$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webappproject";

try {
    $conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $sql = "SELECT * FROM users WHERE userName = '" . $username . "' AND userPWD = '" . $password . "'";

        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $userData = $result->fetch_assoc();

            session_start();
            $_SESSION['user_id'] = $userData['userID'];
            $_SESSION['username'] = $userData['userName'];
            $csrfToken = base64_encode(base64_encode($_SESSION['username'])); 
            $_SESSION['csrf_token'] = $csrfToken; 

            header("Location: profile.php");
            exit();
        } else {
            echo "<p>Invalid username or password. Please try again.</p>";
        }

        $conn->close();
    }
} catch (Exception $e) {
    echo "<div class=\"errormessage\">An error occured, please try again</div>";
}
?>


    
    <form class="loginForm" method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <br><h2 style="text-align: center;">Login</h2><br>
        <input type="text" class="textInput" name="username" placeholder="Username" maxlength="30" required>
        <input type="password" class="textInput" name="password" placeholder="Password" maxlength="30" required><br>
        <input class="logInButton" type="submit" value="Login">
    </form>
    <a href="signup.php">Click here to sign up</a>
</body>
</html>
