<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/laptop.jpg" alt="Phillips Blender">
            <div class="card-body">
                <h5 class="card-title">Lenovo Legion 5i Gaming Laptop</h5>
                <p class="card-text">With a 12th Gen Intel® Core™ processor and an NVIDIA® GeForce RTX™ 3070 Ti GPU. Also features a 15.6″ WQHD screen with a 165Hz refresh rate.</p>
                <p class="card-text">£1299.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>