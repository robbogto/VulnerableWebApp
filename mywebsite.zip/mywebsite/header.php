<!doctype html>
<html lang='en'>

<head>
    <title>Home</title>
    <meta charset="utf-8" />
    <link href="css/mywebsite.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> 

</head>

<body>
    <header>
        <h1>The PVWA Online Store</h1>
        
    
    <nav id="nav-website">
        <ul>
            <li><a href="home.php">Home</a> </li>
            <li><a href="about.php">About</a> </li>
            <li><a href="reviews.php">Reviews</a> </li>
            <li><a href="profile.php">Profile</a> </li>
            <li><a href="login.php">Login</a> </li>
        </ul>
    </nav>
    </header>

    <div class="wrapper">