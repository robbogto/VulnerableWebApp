<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/ssd.jpg" alt="Samsung SSD">
            <div class="card-body">
                <h5 class="card-title">Samsung 2TB SSD</h5>
                <p class="card-text">With 2TB of storage never run out of space again</p>
                <p class="card-text">£149.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>