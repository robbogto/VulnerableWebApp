<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/pc-case.png" alt="Avant PC case">
            <div class="card-body">
                <h5 class="card-title">Avant PC case</h5>
                <p class="card-text">Full size ATX with glass side panel</p>
                <p class="card-text">£129.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>