<?php
    include_once 'header.php';
    
?>
<style>
        .hidden {
            display: none;
        }
    </style>
<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webappproject";

$conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM users WHERE userName = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "No user found.";
}
?>

    <br><div class="card">
    <div class="card-body">
        <h2 class="card-title">  Profile information for: <?php echo $user['userName']; ?></h2>
        <p class="card-text"><strong>First Name:</strong> <?php echo $user['firstName']; ?></p>
        <p class="card-text"><strong>Last Name:</strong> <?php echo $user['lastName']; ?></p>
        <p class="card-text"><strong>Email:</strong> <?php echo $user['email']; ?></p>
        <p class="card-text"><strong>Postcode:</strong> <?php echo $user['postcode']; ?></p>
        <button id="showFormBtn">Edit details</button>
    </div>
</div>

    <form id="myForm" class="hidden" method="POST" action="profileupdate.php">
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="firstName" required><br>
        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="lastName" required><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="postcode">Postcode:</label>
        <input type="text" id="postcode" name="postcode" required><br><br>
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="submit" value="Update Profile">
    </form>

    <script>
        document.getElementById('showFormBtn').addEventListener('click', function() {
            var form = document.getElementById('myForm');
            form.classList.toggle('hidden');
        });
    </script>

<a href="logout.php">Logout</a>


