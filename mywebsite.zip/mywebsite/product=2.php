<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/graphics-card.png" alt="Avant PC case">
            <div class="card-body">
                <h5 class="card-title">NVIDIA RTX 2080 Ti Graphics Card</h5>
                <p class="card-text">With integrated 11GB GDDR6 352-bit memory interface</p>
                <p class="card-text">£329.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>