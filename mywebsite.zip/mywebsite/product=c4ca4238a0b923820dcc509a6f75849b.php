<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/drill.jpg" alt="DeWalt Drill">
            <div class="card-body">
                <h5 class="card-title">DeWalt 18v Cordless Drill</h5>
                <p class="card-text">Comes with a Lithium ion battery and a set of drill bits</p>
                <p class="card-text">£79.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>