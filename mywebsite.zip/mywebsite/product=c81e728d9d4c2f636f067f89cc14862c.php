<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/iphone.jpg" alt="iPhone 14">
            <div class="card-body">
                <h5 class="card-title">iPhone 14 Pro</h5>
                <p class="card-text">A16 Bionic chip and 6.1" Super Retina XDR display</p>
                <p class="card-text">£1099</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>