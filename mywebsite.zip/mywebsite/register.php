<?php
session_start();

include("inc/functions.inc.php");

$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webappproject";

try {
    $conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $userUID = random_num(5);
        $role = "dXNlcg==";

        $query = "INSERT INTO users (userUID, userName, userPWD, role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $userUID, $username, $password, $role);
        $stmt->execute();
        $stmt->close();

        header("Location: login.php");
        exit;
    }
    $conn->close();
} catch (Exception $e) {
    echo "<p>An error occurred, please try again</p>";
}
?>
