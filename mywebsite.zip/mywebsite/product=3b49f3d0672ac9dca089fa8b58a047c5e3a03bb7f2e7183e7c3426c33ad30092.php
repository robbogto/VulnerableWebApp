<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/keyboard.jpg" alt="Wireless Headphones">
            <div class="card-body">
                <h5 class="card-title">Logitech MX Keys Wireless Keyboard</h5>
                <p class="card-text">Full size wireless keyboard with number pad</p>
                <p class="card-text">£99.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



 
<?php
    include_once 'footer.php';
?>