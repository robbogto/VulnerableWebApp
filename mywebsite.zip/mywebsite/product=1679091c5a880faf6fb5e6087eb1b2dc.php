<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/blender.jpg" alt="Phillips Blender">
            <div class="card-body">
                <h5 class="card-title">Phillips Blender</h5>
                <p class="card-text">High power motor makes crushing and blending easy.</p>
                <p class="card-text">£161.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>