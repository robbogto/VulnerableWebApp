<?php
    include_once 'header.php';
?>

    <section class="intro">
        <h1>How to use this website</h1>
        <p>This website has been developed to include instances of variuos web based vulnerabilities. Your aim as the user is to exploit these vulnerabilities by bypassing any security methods that may be in place. This page will act as a guide to the vulnerabilites included and will provide hints and tips.  </p>
    </section>

    <h3>Insecure Direct Object Reference</h3>
    <p> Certain pages exist that should not be accessible</p>
    <button onclick="displayHintIDOR1()">Hint 1</button>
    <button onclick="displayHintIDOR2()">Hint 2</button>
    <button onclick="displayHintIDOR3()">Hint 3</button>
    <button onclick="displayHintIDOR4()">Hint 4</button>
    <p id="IDORresult"></p>
    <script>
        function displayHintIDOR1() {
            document.getElementById("IDORresult").textContent = 'There may be product pages that should not be accessible';
        }
        function displayHintIDOR2() {
            document.getElementById("IDORresult").textContent = 'Try looking at the product ID\'s';
        }
        function displayHintIDOR3() {
            document.getElementById("IDORresult").textContent = 'Certain product ID\'s may have been hashed';
        }
        function displayHintIDOR4() {
            document.getElementById("IDORresult").textContent = 'One of the hidden product pages won\'t be accessible using an IDOR exploit';
        }
    </script>

    <h3>Cross Site Request Forgery</h3>
    <p> Try to force a logged in user to change their email address </p>
    <button onclick="displayHintCSRF1()">Hint 1</button>
    <button onclick="displayHintCSRF2()">Hint 2</button>
    <button onclick="displayHintCSRF3()">Hint 3</button>
    <button onclick="displayHintCSRF4()">Hint 4</button>
    <p id="CSRFresult"></p>
    <script>
        function displayHintCSRF1() {
            document.getElementById("CSRFresult").textContent = 'A user first needs to be logged into the website';
        }
        function displayHintCSRF2() {
            document.getElementById("CSRFresult").textContent = 'Try looking at the request sent when updating profile information';
        }
        function displayHintCSRF3() {
            document.getElementById("CSRFresult").textContent = 'The CSRF token appears to have been encoded...';
        }
        function displayHintCSRF4() {
            document.getElementById("CSRFresult").textContent = 'Try hosting an external page containg the same form as the profile page';
        }
    </script>

    <h3>Cross Site Scripting</h3>
    <p> Try to produce a pop up alert that contains the session cookie using both reflected and stored XSS</p>
    <p>Found the reflected XSS vulnerability? <a href="#" onclick="revealHiddenElement(); return false;">Click here!</a></p>
    <div id="hiddenElement" style="display: none;">
    <p>Try to produce a pop up alert on these search bars, they are more secure than the first! </p>
    <a href="home2.php">Alternate home page 2</a>
    <a href="home3.php">Alternate home page 3</a>
    </div><br>
    <button onclick="displayHintReflected1()">Reflected XSS hint 1</button>
    <button onclick="displayHintReflected2()">Reflected XSS hint 2</button>
    <button onclick="displayHintReflected3()">Reflected XSS hint 3</button>
    <button onclick="displayHintReflected4()">Reflected XSS hint 4</button>
    <p id="RXSSresult"></p>
    <script>
        function revealHiddenElement() {
        var hiddenElement = document.getElementById("hiddenElement");
        hiddenElement.style.display = "block";
        }
        function displayHintReflected1() {
            document.getElementById("RXSSresult").textContent = 'Look for areas that display data from a user';
        }
        function displayHintReflected2() {
            document.getElementById("RXSSresult").textContent = 'Certain characters may be being replaced';
        }
        function displayHintReflected3() {
            document.getElementById("RXSSresult").textContent = 'Try avoiding using script tags';
        }
        function displayHintReflected4() {
            document.getElementById("RXSSresult").textContent = 'The search form on home page 3 is quite secure!';
        }
    </script>
    <button onclick="displayHintStored1()">Stored XSS hint 1</button>
    <button onclick="displayHintStored2()">Stored XSS hint 2</button>
    <button onclick="displayHintStored3()">Stored XSS hint 3</button>
    <button onclick="displayHintStored4()">Stored XSS hint 4</button>

    <p id="SXSSresult"></p>
    <script>
        function displayHintStored1() {
            document.getElementById("SXSSresult").textContent = 'Think about places which display stored data';
        }
        function displayHintStored2() {
            document.getElementById("SXSSresult").textContent = 'One of the input fields on the review form may be vulnerable';
        }
        function displayHintStored3() {
            document.getElementById("SXSSresult").textContent = 'You may need to bypass a length restriction being applied';
        }
        function displayHintStored4() {
            document.getElementById("SXSSresult").textContent = 'Script tags are being replaced';
        }
    </script>

    <h3>SQL Injection</h3>
    <p> Try to gain access to an admin account using SQL injection</p>
    <button onclick="displayHintSQLI1()">Hint 1</button>
    <button onclick="displayHintSQLI2()">Hint 2</button>
    <button onclick="displayHintSQLI3()">Hint 3</button>
    <button onclick="displayHintSQLI4()">Hint 4</button>
    <p id="SQLIresult"></p>
    <script>
        function displayHintSQLI1() {
            document.getElementById("SQLIresult").textContent = 'A field accepting user input will be required ';
        }
        function displayHintSQLI2() {
            document.getElementById("SQLIresult").textContent = 'The username field of the log in page may be worth testing';
        }
        function displayHintSQLI3() {
            document.getElementById("SQLIresult").textContent = 'How might the SQL statement handling the login process be written?';
        }
        function displayHintSQLI4() {
            document.getElementById("SQLIresult").textContent = 'Try using the SQL comment symbol ';
        }
    </script>
<?php
    include_once 'footer.php';
?>

