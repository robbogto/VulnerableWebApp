<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/mouse.jpg" alt="Avant PC case">
            <div class="card-body">
                <h5 class="card-title">Logitech G903 Wireless Mouse</h5>
                <p class="card-text">LIGHTSPEED Wireless Gaming Mouse with HERO Sensor</p>
                <p class="card-text">£139.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



<?php
    include_once 'footer.php';
?>