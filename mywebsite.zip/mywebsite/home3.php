<?php
    include_once 'header.php';
?>
<h2>Trending Products</h2>
<?php
    $serverName = "localhost";
    $dBUsername = "root";
    $dBPassword = "";
    $dBName = "webappproject";

    $conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

    try {
        $sql = "SELECT * FROM products WHERE name LIKE ?";
        $stmt = $conn->prepare($sql);

        $searchPattern = "%$searchTerm%";
        $stmt->bind_param("s", $searchPattern);
        $stmt->execute();
        $result = $stmt->get_result();

        $sanitizedSearchTerm = htmlspecialchars($searchTerm);

        echo '
        <br><form method="get" action="">
            <input type="text" name="search" placeholder="Search products..." value="' . $sanitizedSearchTerm . '">
            <button type="submit">Search</button>
            <a href="?search=">Clear</a>
        </form>';

        if (!empty($searchTerm)) {
            echo '<p>You searched for: ' . $sanitizedSearchTerm . '</p>';
        }

        if ($result->num_rows > 0) {
            echo '<br><div class="container">';
            echo '<div class="row">';

            while ($row = $result->fetch_assoc()) {
                $productId = $row['id'];
                $productName = $row['name'];
                $productDescription = $row['description'];
                $productPrice = $row['price'];
                $productImage = 'images/' . $row['image'];

                echo '
                <div class="col-sm-4">
                    <div class="card">
                        <img class="card-img-top" src="' . $productImage . '" alt="' . $productName . '">
                        <div class="card-body">
                            <h5 class="card-title">' . $productName . '</h5>
                            <p class="card-text">' . $productDescription . '</p>
                            <p class="card-text">£' . $productPrice . '</p>
                            <a href="/mywebsite/product=' . $productId . '.php" class="btn btn-primary">View Product</a>
                        </div>
                    </div>
                </div>
                ';
            }

            echo '</div><br>'; 
            echo '</div>'; 
        } else {
            echo "No products found.";
        }
    } catch (Exception $e) {
        echo "<div class=\"errormessage\">An error occured, please try again</div>";

    }

    $conn->close();
?>

<?php
    include_once 'footer.php';
?>
