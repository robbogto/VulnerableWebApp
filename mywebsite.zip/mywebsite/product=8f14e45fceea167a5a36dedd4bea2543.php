<?php
    include_once 'header.php';
?>

    <br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/flag.jpg" alt="flag">
            <div class="card-body">
                <h5 class="card-title">Flag</h5>
                <p class="card-text">Restricted - this product should not be accessible - Hashing the ID value clearly was not enough </p>
                <p class="card-text">£XXX.XX</p>
                <a href="" class="btn btn-primary">Unavailable</a>
            </div>
            </div>
    </section><br>


<?php
    include_once 'footer.php';
?>