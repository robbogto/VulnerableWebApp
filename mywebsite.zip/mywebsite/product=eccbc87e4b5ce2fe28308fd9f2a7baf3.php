<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div class="card">
                <img class="card-img-top" src="images/headphones.jpg" alt="Wireless Headphones">
            <div class="card-body">
                <h5 class="card-title">JBL Wireless Headphones</h5>
                <p class="card-text">Features ANC and a 30 hour battery life</p>
                <p class="card-text">£78.95</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div>
    </section><br>



 
<?php
    include_once 'footer.php';
?>