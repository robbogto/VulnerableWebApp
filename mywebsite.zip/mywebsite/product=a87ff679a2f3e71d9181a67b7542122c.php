<?php
    include_once 'header.php';
?>
<br>
    <section class="Product">
            <div id="switchCard" class="card">
                <img id="switchCardImg" class="card-img-top" src="images/switch.jpg" alt="Nintendo Switch">
            <div class="card-body">
                <h5 class="card-title">Nintendo Switch</h5>
                <p class="card-text">Designed to play at home or on-the-go</p>
                <p class="card-text">£259.99</p>
                <a href="" class="btn btn-primary">Buy Now</a>
            </div>
            </div><br>
    </section>



<?php
    include_once 'footer.php';
?>