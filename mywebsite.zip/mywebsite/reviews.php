<?php
    include_once 'header.php';

    session_start();

include("inc/dbh.inc.php");

if (isset($_GET['delete_id'])) {
    $deleteId = mysqli_real_escape_string($conn, $_GET['delete_id']);
    $deleteSql = "DELETE FROM reviews WHERE reviewID = '$deleteId'";
    mysqli_query($conn, $deleteSql);
}

$sql = "SELECT * FROM reviews";
$result = mysqli_query($conn, $sql);
?>


<section class="review">
    <h2>Leave a review</h2>
    <p>Please use this page to view customer reviews and leave your own!</p>

<form action="add-review.php" class="reviewForm" method="post">
    <br><input type="text" class="resizedTextbox" name="name" id="name" 
    maxlength="10" placeholder="Name" required><br>
    <input type="text" class="resizedTextbox" name="productName" id="productName" 
    maxlength="20" placeholder="Product name"  required><br>
    <select name="rating" id="rating" required>
        <option value="">Select a rating</option>
        <option value="1">1/5</option>
        <option value="2">2/5</option>
        <option value="3">3/5</option>
        <option value="4">4/5</option>
        <option value="5">5/5</option>
    </select><br>
    <textarea name="comment" class="commentInput" id="comment" placeholder="Comment" required></textarea>
    <br>
    <input type="submit" class="reviewSubmit" value="Submit">
</form>


<h3>User reviews</h3>
<?php
if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
  echo '<div class="card">';
  echo '  <div class="card-body">';
  echo '    <h5 class="card-title">' . preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', 'Invalid', $row['name']) . '</h5>';
  echo '    <h6 class="card-subtitle mb-2 text-muted">' . htmlspecialchars($row['productName']) . '</h6>';
  echo '    <p class="rating">' . $row['rating'] . '/5 </p>';
  echo '    <p class="card-text">' . htmlspecialchars($row['comment']) . '</p>';
  echo '        <a href="?delete_id=' . $row['reviewID'] . '">Delete</a>';
  echo '    </div>';
  echo '  </div>';
  echo '</div><br>';
}
} else {
echo 'No reviews found.';
} 
?>

      



<?php
    include_once 'footer.php';
    
?>

